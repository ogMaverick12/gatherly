# Source hygiene checks

Generated: 2026-10-23
Scope: `src/`, `tests/`, `scripts/`, docs (excluding `node_modules`, `.next`, `coverage`, `test-results`, `playwright-report`, `audit`, `.git`, lockfiles).
Method: plain-text pattern search over file contents. Every hit is listed with file and line, or "none".

## any (TypeScript type annotation)

none

A refined search for `any` used as a type (`: any`, `<any>`, `any[]`, `Array<any>`, `Record<string, any>`) found zero hits in source. The bare word "any" does appear in English prose (prompts, i18n strings, docs) — those are not type annotations.

## @ts-ignore

none (source). Mentioned only as a prohibited practice in AGENTS.md:16 and PLAN.md.

## non-null assertion `!` (postfix)

none (source). The only `/\w!/` hit is test fixture data in `tests/share.test.ts:77` (`'!!!not-base64!!!'`), which is not a TypeScript non-null assertion.

## console.log

none (source). Mentioned only in PLAN.md.

## eslint-disable

none (source). Mentioned only as a prohibited practice in AGENTS.md:16.

## TODO

none

## FIXME

none

## dangerouslySetInnerHTML

none (source). Mentioned only in SECURITY.md:135 as a prohibited practice.

## animejs outside `src/lib/motion`

none (source). Mentioned only in AGENTS.md:34 and PLAN.md as a rule.

## Secret patterns (`AIza…`, `sk-or/proj/live/test…`, `github_pat_…`, `xoxb…`, raw 32+ char hex)

none outside lockfiles.

The `Bearer` string appears in three places, all constructing an `Authorization` header from a variable/environment value, never a literal key:
- `src/lib/ai/openrouter.ts:29` — `Authorization: \`Bearer ${this.apiKey}\``
- `src/lib/security/rate-limit.ts:94` — `Authorization: \`Bearer ${this.token}\``
- `tests/security/adapters.test.ts:104` — `expect(headers?.['Authorization']).toBe('Bearer key')`

No `AIza`, `sk-`, `github_pat_`, or `xoxb-` literal was found. `tsconfig.tsbuildinfo` is a generated build artifact (gitignored) and was excluded.

## Hard-coded hex colour outside `tokens.ts` and `globals.css`

`src/app/layout.tsx:64` — `color: '#FBF6EE'`
`src/app/layout.tsx:65` — `color: '#17120F'`

These duplicate token values for the `theme-color` meta tag. No other hard-coded hex was found outside `tokens.ts` and `globals.css`.

## Files over 200 lines (AGENTS.md rule 8)

315	scripts/live-smoke.mjs
309	src/features/assistant/parse.ts
291	src/features/assistant/services.ts
593	src/features/intake/components/IntakeForm.tsx
537	src/features/timeline/services.ts
490	src/features/budget/services.ts
390	src/features/vendors/services.ts
346	src/features/ideas/services.ts
224	src/features/health/services.ts
224	src/features/workspace/components/AssistantPanel.tsx
221	src/features/workspace/components/BudgetPanel.tsx
207	src/features/workspace/components/OverviewPanel.tsx

`tsconfig.tsbuildinfo` is generated and excluded.

## Exported functions without a preceding JSDoc comment

AGENTS.md rule 14 requires JSDoc on every exported function in `services/` and `lib/`. Reported here for every exported function/arrow/component for completeness:

`src/app/api/chat/route.ts:24` — `export async function POST`
`src/app/api/health/route.ts:18` — `export async function GET`
`src/app/api/ideas/route.ts:24` — `export async function POST`
`src/app/api/parse/route.ts:26` — `export async function POST`
`src/features/accessibility/components/DisplaySettings.tsx:27` — `export function DisplaySettings`
`src/features/accessibility/components/OfflineBanner.tsx:12` — `export function OfflineBanner`
`src/features/accessibility/components/ServiceWorkerRegistrar.tsx:11` — `export function ServiceWorkerRegistrar`
`src/features/accessibility/provider.tsx:68` — `export function writeStoredPreferences`
`src/features/accessibility/provider.tsx:93` — `export function AccessibilityProvider`
`src/features/accessibility/provider.tsx:182` — `export function useAccessibility`
`src/features/assistant/parse.ts:277` — `export function parseFreeText`
`src/features/assistant/services.ts:52` — `export function buildSnapshot`

(React component exports and route handlers are outside the strict `services/`/`lib/` JSDoc rule; service and library exports should carry JSDoc per rule 14.)

## API routes not wrapped in `withGuards`

none. All four API routes route through the guard chain:
- `src/app/api/chat/route.ts` — wrapped (rate limit, body cap, Zod, SSE)
- `src/app/api/health/route.ts` — wrapped (rate limit)
- `src/app/api/ideas/route.ts` — wrapped
- `src/app/api/parse/route.ts` — wrapped

All four declare `runtime = 'nodejs'` and `dynamic = 'force-dynamic'`.
