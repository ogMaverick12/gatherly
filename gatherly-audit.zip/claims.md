# Claims audit

Generated: 2026-10-23
Every number or factual claim in the README and docs, each mapped to the command or file that proves it, or marked `unverified` where no proof exists.

## README.md

| Claim | Location | Proof | Status |
|---|---|---|---|
| Lint clean, 0 warnings (`--max-warnings=0`) | Verification table | `outputs/check.txt` (eslint exit 0) | proven |
| Typecheck clean, strict | Verification table | `outputs/check.txt` (tsc exit 0) | proven |
| Format clean, Prettier | Verification table | `outputs/check.txt` (prettier exit 0) | proven |
| Test:coverage passes, thresholds hold | Verification table | `outputs/coverage.txt` (exit 0; thresholds enforced) | proven |
| Build compiles `/`, `/intake`, `/plan`, API routes | Verification table | `outputs/build.txt` (exit 0; 8 routes listed) | proven |
| `npm run test:e2e` passes | Verification table | `outputs/e2e.txt` (13 passed) | proven |
| `npm audit --omit=dev`: 0 vulnerabilities | Verification table | `outputs/audit-omit-dev.txt` | proven |
| Coverage thresholds 90 / 70 / 90 / 90 | "Coverage thresholds are enforced..." | `vitest.config.mts` thresholds block | proven |
| 44px targets | "Accessibility and display" | design claim; no automated 44px assertion (no `tests/e2e/layout.spec.ts` exists) | design claim |
| Three text sizes, light/dark/system themes | "Accessibility and display" | implemented in accessibility provider (code) | proven (code) |
| No `NEXT_PUBLIC_` variant; all vars server-only | Environment table | code search: no `NEXT_PUBLIC_` in src/ | proven |
| Basic mode works with no keys | "What switches the AI on" | `npm run test` passes with no keys; live-smoke skipped | proven |
| Deployed demo shows "AI assisted" badge | "What switches the AI on" | **unverified** — no deployment exists; `docs/LIVE_VERIFICATION.md` records this | unverified |
| What was verified is in docs/LIVE_VERIFICATION.md | "What switches the AI on" | `docs/LIVE_VERIFICATION.md` exists | proven (doc exists) |

## SECURITY.md

| Claim | Location | Proof | Status |
|---|---|---|---|
| Rate limit: 20 requests/min per route per client key, Retry-After on refusal | §2.1 | `src/lib/security/guards.ts` (enforceRateLimit) | proven |
| Body cap 16 KiB, streamed, 413 on overflow | §2.1 | `src/lib/security/guards.ts` (MAX_BODY_BYTES) | proven |
| Route timeout 20s; provider 15s | §2.4 | `src/lib/security/guards.ts` (ROUTE_TIMEOUT_MS) | proven |
| One retry for 429/502/503/504 | §2.4 | `src/lib/ai/` retry logic | proven |
| Production = Upstash shared store; local default = per-instance | §2.2 | `src/lib/security/rate-limit.ts`, `GET /api/health` | proven (code) |
| `GET /api/health` reports `rateLimit: shared \| per-instance` | §2.2 | `src/app/api/health/route.ts`, `tests/api/health.test.ts` | proven |
| Production start without variables logs one warning | §2.2 | `src/instrumentation.ts`, `rate-limit.ts` | proven (code) |
| style-src allows unsafe-inline (Next/UI inject styles); scripts nonce-only | §2.8 | `src/middleware.ts` CSP | proven (code) |
| 7 high advisories, dev toolchain only | §3 | `outputs/audit.txt` | proven |
| 0 vulnerabilities (`--omit=dev`) | §3 | `outputs/audit-omit-dev.txt` | proven |

## docs/DELIVERY_OUTCOMES.md

| Claim | Location | Proof | Status |
|---|---|---|---|
| 37 files, 503 tests, 503 passed, 0 failed | Verification summary | `outputs/coverage.txt`; vitest run (503 passed) | proven |
| Coverage 92.86% statements / 79.15% branches / 92.2% functions / 94.56% lines | Verification summary | `outputs/coverage.txt` | proven |
| 13 passed e2e (3 journeys, 5 quality flows, 5 axe screens) | Verification summary | `outputs/e2e.txt` | proven |
| npm audit: 7 vulnerabilities, dev toolchain | Verification summary | `outputs/audit.txt` | proven |
| /plan first-load JS 161 kB; shared 103 kB | Verification summary | `outputs/build.txt`; `outputs/bundle-budget.txt` | proven |
| Per-file test counts (table) | Tests per file | `outputs/` + inventory scan (it()/test() call sites = 504 total; vitest executed 503) | proven (1-test diff is parameterized-case counting) |
| Health score 0-100, five weighted parts | Outcomes 9 / checks.md | `src/features/health/services.ts` | proven (code) |
| 8% contingency | README mapping table; code | `src/features/budget/services.ts` allocation tables | proven (code) |
| 44px targets | Outcome 8 | design claim (see README row above) | design claim |
| Works offline | Outcome 7 / e2e flow | `public/sw.js`; `tests/e2e/quality.spec.ts` offline reload test; e2e passed | proven |
| `/api/*` never cached | Outcome 7 | `public/sw.js` returns early for `/api/`; e2e "no API answer is kept in the cache" | proven |
| Coverage not 100% | Known gaps §4 | `outputs/coverage.txt` (e.g. 79.15% branches) | proven |

## PLAN.md (score strategy / self-assessment)

| Claim | Location | Proof | Status |
|---|---|---|---|
| Problem alignment 100, Code quality 100, Security 100, Efficiency 85, Testing 100, Accessibility 100 | Score table | self-reported from prior event; not re-measured here | self-assessment |
| 250+ tests target | Testing plan | actual: 503 tests | proven (exceeds target) |
| First-load JS /plan within 10% of 161 kB | G5 step 5 | `outputs/bundle-budget.txt` (161 kB = baseline, BUDGET OK) | proven |
| vitest upgraded to current major | G5 step 4 | `package.json` vitest ^5.0.5, @vitest/coverage-v8 ^5.0.5 | proven |

## Lighthouse (desktop, production build via `npm start`)

| Page | Performance | Accessibility | Best Practices | SEO | Proof |
|---|---|---|---|---|---|
| / | 100 | 100 | 100 | 90 | `outputs/lighthouse-root.json` |
| /intake | 100 | 100 | 100 | 90 | `outputs/lighthouse-intake.json` |
| /plan | 100 | 100 | 100 | 90 | `outputs/lighthouse-plan.json` |

## Not proven / unverified

- The deployed-demo "AI assisted" badge and live provider calls (no keys, no deployment). `scripts/live-smoke.mjs` reports both providers skipped.
- `docs/LIVE_VERIFICATION.md` records that `GET /api/health` would report `shared` once the owner sets `UPSTASH_REDIS_REST_URL`/`TOKEN` on the deployment; not yet observed live.
