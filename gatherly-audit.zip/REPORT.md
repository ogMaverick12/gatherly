# Audit handoff report

Generated: 2026-10-23
Working tree: C:\Users\sreej\Downloads\Projects\Gatherly
Not a git repository: no commit hash or branch is available.
Node: v24.20.0
npm: 11.19.0

## Exact commands run

| # | Command | Exit code | Output file |
|---|---------|-----------|-------------|
| 1 | `npm run check` | 0 | outputs/check.txt |
| 2 | `npm run build` | 0 | outputs/build.txt |
| 3 | `npm run test:coverage` | 0 | outputs/coverage.txt |
| 4 | `CI=true npm run e2e` | 0 | outputs/e2e.txt |
| 5 | `npm audit` | 1 (findings reported) | outputs/audit.txt |
| 6 | `npm audit --omit=dev` | 0 | outputs/audit-omit-dev.txt |
| 7 | `npx depcheck` | -1 (reports unused dev deps) | outputs/depcheck.txt |
| 8 | `node scripts/check-bundle.mjs` | 0 | outputs/bundle-budget.txt |
| 9 | `node scripts/live-smoke.mjs` | 0 | outputs/live-smoke.txt |
| 10 | `npx lighthouse` (x3: /, /intake, /plan) | 0 | outputs/lighthouse-{root,intake,plan}.json |

`npm audit` exits 1 because it reports findings; that is expected and not a failure of the app. `npx depcheck` exits -1 because it reports unused dev dependencies; likewise informational.

## Headline results

- `npm run check`: clean (lint 0 warnings, typecheck clean, Prettier clean, coverage thresholds enforced and met)
- `npm run build`: succeeds; all 8 routes compile
- `npm run test:coverage`: 503 tests passed; coverage 92.86% statements / 79.15% branches / 92.2% functions / 94.56% lines (thresholds 90/70/90/90 enforced)
- `npm run e2e`: 13 passed
- `npm audit --omit=dev`: 0 vulnerabilities
- `npm audit`: 7 high severity, all in the development toolchain (Tailwind 3 braces chain; Next ESLint config fast-glob chain). None ships; fixes require breaking major upgrades (Tailwind 4, eslint-config-next downgrade incompatible with Next 15). Documented in SECURITY.md §3.
- `npx depcheck`: 5 unused devDependencies flagged (autoprefixer, eslint-config-next, eslint-import-resolver-typescript, eslint-plugin-jsx-a11y, postcss)
- Bundle budget: /plan first-load JS = 161 kB, baseline 161 kB, budget <= 177.1 kB → BUDGET OK
- Live smoke: skipped (no GEMINI_API_KEY / OPENROUTER_API_KEY in environment); no live AI call made
- Lighthouse (desktop, production build served via `npm start`):
  - /: performance 100, accessibility 100, best-practices 100, seo 90
  - /intake: performance 100, accessibility 100, best-practices 100, seo 90
  - /plan: performance 100, accessibility 100, best-practices 100, seo 90

## Contents of audit/

- outputs/ — full command output for every command above
- inventory.md — file tree, 20 largest source files, test counts per file, dependency list, route settings
- checks.md — results of every required source search
- claims.md — every number/factual claim in README and docs, with proof or 'unverified'
- screens/ — PNGs from the visual QA harness (none produced; see NOTES.md)
- NOTES.md — what was skipped, what failed, and open questions
