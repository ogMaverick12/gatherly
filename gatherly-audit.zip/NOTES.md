# Audit notes

Generated: 2026-10-23

## What was skipped

- **Visual QA harness / screenshots (`audit/screens/`)** — the V1 visual QA harness (`scripts/capture-screens.mjs`, `tests/e2e/layout.spec.ts`) was never implemented in this working tree, so no PNGs were produced. `audit/screens/` is empty.
- **Lighthouse on mobile / throttled** — only desktop preset runs were captured (`/`, `/intake`, `/plan`).
- **Next bundle analyzer / five largest client dependencies** — not run (P1 step 4).
- **Deployment / Vercel / live smoke against a deployed URL** — no deployment exists; `scripts/live-smoke.mjs` was run locally with no keys (both providers skipped).
- **git-based items** — this is not a git repository, so there is no commit hash or branch to record.

## What failed

- `npm audit` exits 1 — expected: it reports 7 high severity findings in the dev toolchain. Not an app failure.
- `npx depcheck` exits -1 — expected: it reports 5 unused devDependencies. Informational only.
- Lighthouse on `/` failed the first two attempts (NO_NAVSTART trace error, then a Chrome interstitial) and succeeded on the third attempt. Transient; final report captured.

## What I am unsure of

- **depcheck's 5 flagged devDependencies** (`autoprefixer`, `eslint-config-next`, `eslint-import-resolver-typescript`, `eslint-plugin-jsx-a11y`, `postcss`): depcheck may not detect usage through config files (e.g. `eslint-config-next` is referenced by `eslint.config.mjs`). Review manually before removing any.
- **Hard-coded hex in `src/app/layout.tsx:64-65`** (`#FBF6EE`, `#17120F` for theme-color meta tags): these duplicate token values but are meta-tag values, not UI colours. Refactoring them to tokens is optional.
- **Test-count discrepancy**: source scan counts 504 `it(`/`test(` call sites across 37 files; `npm run test:coverage` executed 503 tests. The 1-test difference is parameterized `it.each` cases expanding at runtime. Not a problem, but the two counting methods differ by one.
- **Unused-dependency reasons**: the README does not document a per-dependency reason (AGENTS.md rule 13 intent), so every dependency in `inventory.md` is listed as "not stated in README".
- **Whether the bundled `tsconfig.tsbuildinfo`** (a generated build artifact, gitignored) should be considered in any hygiene count — it was excluded from source counts.
