# Audit inventory

Generated: 2026-10-23

## File tree (3 levels, excluding node_modules, .next, coverage, test-results, playwright-report, audit, .git)

.env.example
.gitignore
.prettierignore
AGENTS.md
PLAN.md
README.md
SECURITY.md
docs/ARCHITECTURE.md
docs/DELIVERY_OUTCOMES.md
docs/JUDGES_TOUR.md
docs/LIMITATIONS.md
docs/LIVE_VERIFICATION.md
docs/TRACEABILITY.md
docs/brief/Gatherly delivery outcomes.md
docs/brief/Gatherly implementation plan.md
docs/brief/Gatherly.md
eslint.config.mjs
next-env.d.ts
next.config.ts
package-lock.json
package.json
playwright.config.ts
postcss.config.mjs
prettier.config.mjs
public/icons/icon.svg
public/manifest.webmanifest
public/sw.js
scripts/check-bundle.mjs
scripts/live-smoke.mjs
scripts/stats.mjs
src/app/globals.css
src/app/layout.tsx
src/app/page.tsx
src/instrumentation.ts
src/lib/api-schema.ts
src/lib/csv.ts
src/lib/dates.ts
src/lib/download.ts
src/lib/ics.ts
src/lib/money.ts
src/lib/plan-store.ts
src/lib/plan-view.ts
src/lib/plan.ts
src/lib/share.ts
src/middleware.ts
src/types/jest-axe.d.ts
tailwind.config.ts
tests/README.md
tests/accessibility/axe.test.tsx
tests/accessibility/contrast.test.ts
tests/ai.test.ts
tests/api/health.test.ts
tests/api/routes.test.ts
tests/assistant.test.ts
tests/budget.test.ts
tests/catering.test.ts
tests/components/accessibility.test.tsx
tests/components/basics.test.tsx
tests/components/intake.test.tsx
tests/components/landing.test.tsx
tests/components/panels-extra.test.tsx
tests/components/panels.test.tsx
tests/components/plan-restore.test.tsx
tests/components/plan-workspace.test.tsx
tests/components/vendors.test.tsx
tests/csv.test.ts
tests/dates.test.ts
tests/e2e/journey.spec.ts
tests/e2e/quality.spec.ts
tests/guards.test.ts
tests/health.test.ts
tests/helpers.tsx
tests/i18n.test.ts
tests/ics.test.ts
tests/ideas.test.ts
tests/instrumentation.test.ts
tests/money.test.ts
tests/parse.test.ts
tests/plan-store.test.ts
tests/plan.test.ts
tests/property.test.ts
tests/risks.test.ts
tests/sanitize.test.ts
tests/security/adapters.test.ts
tests/security/providers.test.ts
tests/setup.ts
tests/share.test.ts
tests/timeline.test.ts
tests/vendors.test.ts
tsconfig.json
tsconfig.tsbuildinfo
vitest.config.mts

## 20 largest source files (lines)

829	src/lib/plan.ts
593	src/features/intake/components/IntakeForm.tsx
537	src/features/timeline/services.ts
490	src/features/budget/services.ts
396	src/features/workspace/components/VendorsPanel.tsx
390	src/features/vendors/services.ts
346	src/features/ideas/services.ts
329	src/features/workspace/components/PlanWorkspace.tsx
309	src/features/assistant/parse.ts
291	src/features/assistant/services.ts
240	src/lib/i18n/en.ts
237	src/lib/security/guards.ts
229	src/lib/i18n/bn.ts
229	src/lib/i18n/hi.ts
224	src/features/health/services.ts
224	src/features/workspace/components/AssistantPanel.tsx
221	src/features/workspace/components/BudgetPanel.tsx
207	src/features/workspace/components/OverviewPanel.tsx
194	src/features/accessibility/components/DisplaySettings.tsx
189	src/features/accessibility/provider.tsx

Note: AGENTS.md rule 8 keeps files under 200 lines; several files predate that rule or are generated/barrel-adjacent. `tsconfig.tsbuildinfo` (generated) is not counted as source.

## Test counts per file (`it(` / `test(` call sites)

14	tests/accessibility/axe.test.tsx
9	tests/accessibility/contrast.test.ts
11	tests/ai.test.ts
9	tests/api/health.test.ts
18	tests/api/routes.test.ts
14	tests/assistant.test.ts
15	tests/budget.test.ts
9	tests/catering.test.ts
16	tests/components/accessibility.test.tsx
25	tests/components/basics.test.tsx
8	tests/components/intake.test.tsx
6	tests/components/landing.test.tsx
14	tests/components/panels-extra.test.tsx
25	tests/components/panels.test.tsx
2	tests/components/plan-restore.test.tsx
8	tests/components/plan-workspace.test.tsx
14	tests/components/vendors.test.tsx
10	tests/csv.test.ts
11	tests/dates.test.ts
3	tests/e2e/journey.spec.ts
8	tests/e2e/quality.spec.ts
22	tests/guards.test.ts
8	tests/health.test.ts
0	tests/helpers.tsx
5	tests/i18n.test.ts
12	tests/ics.test.ts
17	tests/ideas.test.ts
2	tests/instrumentation.test.ts
14	tests/money.test.ts
13	tests/parse.test.ts
10	tests/plan-store.test.ts
13	tests/plan.test.ts
26	tests/property.test.ts
21	tests/risks.test.ts
14	tests/sanitize.test.ts
13	tests/security/adapters.test.ts
19	tests/security/providers.test.ts
0	tests/setup.ts
16	tests/share.test.ts
14	tests/timeline.test.ts
27	tests/vendors.test.ts

Total call sites: 504 across 37 unit test files. `npm run test:coverage` reports 503 executed tests (parameterized `it.each` cases expand at runtime; one test is conditionally skipped). Source files under src: 68. UI components: 23. API routes: 4. Feature slices: 11.

## Dependencies (package.json) with README reason

README.md does not maintain a per-dependency reason table (AGENTS.md rule 13 asks for a one-line reason when a dependency is added, but that rationale lives in commit/PR history, not the README). The README's environment table covers server env vars only; its banned-dependency note lists jspdf, moment, lodash and UI kits other than shadcn/ui.

### dependencies
| Dependency | Version | README reason |
|---|---|---|
| @google/genai | ^2.30.0 | not stated in README |
| @hookform/resolvers | ^3.9.1 | not stated in README |
| next | ^15.1.7 | not stated in README |
| react | ^19.0.0 | not stated in README |
| react-dom | ^19.0.0 | not stated in README |
| react-hook-form | ^7.54.2 | not stated in README |
| zod | ^3.24.2 | not stated in README |

### devDependencies
| Dependency | Version | README reason |
|---|---|---|
| @axe-core/playwright | ^4.14.0 | not stated in README |
| @eslint/eslintrc | ^3.3.1 | not stated in README |
| @playwright/test | ^1.49.1 | not stated in README |
| @testing-library/jest-dom | ^6.6.3 | not stated in README |
| @testing-library/react | ^16.2.0 | not stated in README |
| @testing-library/user-event | ^14.6.1 | not stated in README |
| @types/node | ^22.13.4 | not stated in README |
| @types/react | ^19.0.8 | not stated in README |
| @types/react-dom | ^19.0.3 | not stated in README |
| @vitest/coverage-v8 | ^5.0.5 | not stated in README |
| autoprefixer | ^10.4.20 | not stated in README |
| eslint | ^9.20.1 | not stated in README |
| eslint-config-next | ^15.1.7 | not stated in README |
| eslint-import-resolver-typescript | ^4.4.5 | not stated in README |
| eslint-plugin-import | ^2.32.0 | not stated in README |
| eslint-plugin-jsx-a11y | ^6.10.2 | not stated in README |
| eslint-plugin-vitest | ^0.5.4 | not stated in README |
| fast-check | ^4.10.2 | not stated in README |
| jest-axe | ^11.0.0 | not stated in README |
| jsdom | ^26.0.0 | not stated in README |
| postcss | ^8.5.23 | not stated in README |
| prettier | ^3.9.10 | not stated in README |
| tailwindcss | ^3.4.17 | not stated in README |
| typescript | ^5.7.3 | not stated in README |
| vitest | ^5.0.5 | not stated in README |

## API routes: runtime and dynamic settings

| Route | runtime | dynamic |
|---|---|---|
| src/app/api/chat/route.ts | nodejs | force-dynamic |
| src/app/api/health/route.ts | nodejs | force-dynamic |
| src/app/api/ideas/route.ts | nodejs | force-dynamic |
| src/app/api/parse/route.ts | nodejs | force-dynamic |

All four routes are Node runtime, force-dynamic (no static prerendering), consistent with stateless guarded API routes.
